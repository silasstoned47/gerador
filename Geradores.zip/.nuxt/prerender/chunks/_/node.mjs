import { Resvg } from 'file://D:/Projetos/Geradores/node_modules/@resvg/resvg-js/index.js';

const node = {
  initWasmPromise: Promise.resolve(),
  Resvg: Resvg
};

export { node as default };
//# sourceMappingURL=node.mjs.map
