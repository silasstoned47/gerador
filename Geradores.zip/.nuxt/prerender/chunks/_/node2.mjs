import _satori from 'file://D:/Projetos/Geradores/node_modules/satori/dist/index.js';

const node = {
  initWasmPromise: Promise.resolve(),
  satori: _satori
};

export { node as default };
//# sourceMappingURL=node2.mjs.map
