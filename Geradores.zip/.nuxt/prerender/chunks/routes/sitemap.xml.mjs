import { defineEventHandler } from 'file://D:/Projetos/Geradores/node_modules/h3/dist/index.mjs';

const sitemap_xml = defineEventHandler(async (event) => {
  try {
    const routes = [
      { loc: "/", changefreq: "daily", priority: 1 },
      { loc: "/desenvolvedores", changefreq: "monthly", priority: 0.7 },
      { loc: "/termos", changefreq: "monthly", priority: 0.3 },
      { loc: "/todas-ferramentas", changefreq: "weekly", priority: 0.8 },
      { loc: "/categorias/contatos", changefreq: "weekly", priority: 0.7 },
      { loc: "/categorias/documentos-pessoais", changefreq: "weekly", priority: 0.9 },
      { loc: "/categorias/documentos", changefreq: "weekly", priority: 0.8 },
      { loc: "/categorias/veiculos", changefreq: "weekly", priority: 0.7 },
      { loc: "/gerador/celular", changefreq: "weekly", priority: 0.8 },
      { loc: "/gerador/cnpj", changefreq: "weekly", priority: 0.9 },
      { loc: "/gerador/cpf", changefreq: "weekly", priority: 1 },
      { loc: "/validadores/celular", changefreq: "weekly", priority: 0.7 },
      { loc: "/validadores/cnpj", changefreq: "weekly", priority: 0.8 },
      { loc: "/validadores/cpf", changefreq: "weekly", priority: 0.9 }
    ];
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
      <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
              http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
        ${routes.map(
      (route) => `
          <url>
            <loc>https://geradorii.com${route.loc}</loc>
            <changefreq>${route.changefreq}</changefreq>
            <priority>${route.priority}</priority>
            <lastmod>${(/* @__PURE__ */ new Date()).toISOString()}</lastmod>
          </url>
        `
    ).join("")}
      </urlset>`;
    event.node.res.setHeader("Content-Type", "application/xml");
    event.node.res.statusCode = 200;
    return sitemap;
  } catch (error) {
    console.error("Error generating sitemap:", error);
    event.node.res.statusCode = 500;
    return "Error generating sitemap";
  }
});

export { sitemap_xml as default };
//# sourceMappingURL=sitemap.xml.mjs.map
