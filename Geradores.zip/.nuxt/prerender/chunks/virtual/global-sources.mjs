const sources = [
    {
        "context": {
            "name": "sitemap:urls",
            "description": "Set with the `sitemap.urls` config."
        },
        "urls": [],
        "sourceType": "user"
    },
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/dev"
            },
            {
                "loc": "/"
            },
            {
                "loc": "/termos"
            },
            {
                "loc": "/gerador/cpf"
            },
            {
                "loc": "/gerador/cnpj"
            },
            {
                "loc": "/gerador"
            },
            {
                "loc": "/desenvolvedores"
            },
            {
                "loc": "/gerador/celular"
            },
            {
                "loc": "/validadores/cpf"
            },
            {
                "loc": "/validadores/cnpj"
            },
            {
                "loc": "/todas-ferramentas"
            },
            {
                "loc": "/validadores"
            },
            {
                "loc": "/categorias/contatos"
            },
            {
                "loc": "/categorias/veiculos"
            },
            {
                "loc": "/validadores/celular"
            },
            {
                "loc": "/categorias/documentos"
            },
            {
                "loc": "/categorias/documentos-pessoais"
            }
        ],
        "sourceType": "app"
    },
    {
        "context": {
            "name": "nuxt:prerender",
            "description": "Generated at build time when prerendering.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:prerender'] }`."
            ]
        },
        "urls": [
            "/",
            "/gerador",
            "/gerador/cpf",
            "/gerador/celular",
            "/gerador/cnpj",
            "/validadores",
            "/validadores/cpf",
            "/validadores/celular",
            "/validadores/cnpj"
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
