<template>
  <div>
    <h1>Documentos Pessoais</h1>
    <p>Ferramentas para geração e validação de documentos pessoais.</p>
    <!-- Add your content here -->
  </div>
</template>

<script setup>
definePageMeta({
  title: 'Documentos Pessoais',
  description: 'Ferramentas para documentos pessoais'
});
</script>
