<template>
  <div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Termos de Uso</h1>
    <div class="prose max-w-none">
      <p>Última atualização: 09 de Agosto de 2025</p>
      
      <h2>1. Aceitação dos Termos</h2>
      <p>Ao acessar e usar este site, você concorda em ficar vinculado por estes Termos de Uso.</p>
      
      <h2>2. Uso das Ferramentas</h2>
      <p>As ferramentas fornecidas são para fins informativos e não devem ser usadas para atividades ilegais ou fraudulentas.</p>
      
      <h2>3. Responsabilidade</h2>
      <p>Não nos responsabilizamos pelo uso indevido das ferramentas fornecidas neste site.</p>
      
      <h2>4. Alterações nos Termos</h2>
      <p>Reservamos o direito de modificar estes termos a qualquer momento. As alterações entrarão em vigor imediatamente após a publicação.</p>
    </div>
  </div>
</template>

<script setup>
definePageMeta({
  title: 'Termos de Uso',
  description: 'Termos de Uso do site de ferramentas online'
});
</script>
