<template>
  <div>
    <h1>Todas as Ferramentas</h1>
    <p>Lista completa de todas as ferramentas disponíveis.</p>
    <!-- Add your content here -->
  </div>
</template>

<script setup>
definePageMeta({
  title: 'Todas as Ferramentas',
  description: 'Lista completa de ferramentas disponíveis'
});
</script>
